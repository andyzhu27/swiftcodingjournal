class Splitwise
{
    func split(amount: Double, lender: String, NumberofBorrowers: Int)
    {
        let totalPeople = Double(NumberofBorrowers + 1);
        let borrowerPayBack = amount / totalPeople;
        print("Each borrower owes \(lender) $\(borrowerPayBack)");
    }
}

let splitwise = Splitwise();
splitwise.split(amount: 111, lender: "Alice", NumberofBorrowers: 3)

