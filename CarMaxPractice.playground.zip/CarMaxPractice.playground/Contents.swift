import Foundation

// Define a structure to represent a Car
struct Car {
    let make: String
    let model: String
    let year: Int
    let horsepower: Int
    let mpg: Double
    let price: Double
    let isSportsCar: Bool
}

// Define user preferences with weightage for different features
struct UserPreference {
    let sportsCarWeight: Double
    let mpgWeight: Double
    let priceWeight: Double
    let horsepowerWeight: Double
}

// Function to compute a score based on user preferences
func computeScore(for car: Car, using preference: UserPreference) -> Double {
    let sportsCarScore = car.isSportsCar ? 1.0 : 0.0
    return (sportsCarScore * preference.sportsCarWeight) +
           (car.mpg * preference.mpgWeight) +
           ((1.0 / car.price) * preference.priceWeight * 10000) +
           (Double(car.horsepower) * preference.horsepowerWeight)
}

// Function to compare three cars
func compareCars(car1: Car, car2: Car, car3: Car, preference: UserPreference) {
    let scores =
    [
        (car1, computeScore(for: car1, using: preference)),
        (car2, computeScore(for: car2, using: preference)),
        (car3, computeScore(for: car3, using: preference))
    ]
    
    let sortedCars = scores.sorted { $0.1 > $1.1 }
    
    print("Car Rankings Based on Your Preferences:")
    for (index, (car, score)) in sortedCars.enumerated() {
        print("\(index + 1). \(car.make) \(car.model) (\(car.year)) - Score: \(score)")
    }
}

// Example Usage
let car1 = Car(make: "Porsche", model: "911", year: 2023, horsepower: 473, mpg: 18.0, price: 120000, isSportsCar: true)
let car2 = Car(make: "Toyota", model: "Camry", year: 2023, horsepower: 203, mpg: 28.0, price: 27000, isSportsCar: false)
let car3 = Car(make: "Chevrolet", model: "Corvette", year: 2023, horsepower: 495, mpg: 19.0, price: 65000, isSportsCar: true)

let userPref = UserPreference(sportsCarWeight: 10.0, mpgWeight: 1.0, priceWeight: 2.0, horsepowerWeight: 5.0)

compareCars(car1: car1, car2: car2, car3: car3, preference: userPref)
