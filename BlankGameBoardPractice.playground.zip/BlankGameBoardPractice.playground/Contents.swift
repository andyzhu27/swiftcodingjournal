import Foundation

// Create a 3x3 blank game board.
var gameBoard = Array(repeating: Array(repeating: " ", count: 3), count: 3)

// Function to display the game board.
func displayBoard(_ board: [[String]]) {
    for row in board {
        print(row.joined(separator: " | "))
    }
    print("") // Adds an extra newline for spacing.
}

// Print the blank game board.
displayBoard(gameBoard)
